package EmployeeObject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class EmployeeBOImpl implements EmployeeBO
{
	static final String url="jdbc:mysql://localhost:3306/advjava";
	static final String username="root";
	static final String password="Nithish@123";
	
	private static Connection conncetion;
	private static PreparedStatement statemnt;

	static final String INSERT_QUERY="insert into `employee`(id,name,email,department,salary) values(?,?,?,?,?)";
	static final String UPDATE_QUERY="update `employee` set `name`=? ,`email`=? ,`department`=?, `salary`=? where `id`=?";
	static final String DELETE_QUERY="delete from `employee` where `id`=?";
	static final String SELECT_QUERY="select * from employee where id=?";
	static final String SELECT_QUERY1="select * from employee";
	

	
	
	public EmployeeBOImpl()
	{
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			conncetion=DriverManager.getConnection(url, username, password);
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	public int save(Employee e)
	{
		try {
			statemnt=conncetion.prepareStatement(INSERT_QUERY);
			statemnt.setInt(1, e.getId());
			statemnt.setString(2, e.getName());
			statemnt.setString(3, e.getEmail());
			statemnt.setString(4, e.getDepartment());
			statemnt.setInt(5, e.getSalary());
			return statemnt.executeUpdate();
		} 
		catch (SQLException e1) {
			e1.printStackTrace();
		}
		return 0;
	}
	
	
	public int update(Employee e)
	{
		try {
			statemnt=conncetion.prepareStatement(UPDATE_QUERY);
			statemnt.setString(1, e.getName());
			statemnt.setString(2, e.getEmail());
			statemnt.setString(3, e.getDepartment());
			statemnt.setInt(4, e.getSalary());
			statemnt.setInt(5, e.getId());
			return statemnt.executeUpdate();
		} 
		catch (SQLException e1) {
			e1.printStackTrace();
		}
		return 0;
	}
	
	
	public int delete(int id)
	{
		try {
			statemnt=conncetion.prepareStatement(DELETE_QUERY);
			statemnt.setInt(1, id);
			return statemnt.executeUpdate();
		} 
		catch (SQLException e1) {
			e1.printStackTrace();
		}
		return 0;
	}
	
	public int delete(Employee e)
	{
		return delete(e.getId());
	}
	
	
	public Employee get(int Id)
	{
		try
		{
			statemnt=conncetion.prepareStatement(SELECT_QUERY);
			statemnt.setInt(1,Id);
			ResultSet res=statemnt.executeQuery();
			while(res.next())
			{
				int id=res.getInt("id");
				String name=res.getString("name");
				String email=res.getString("email");
				String department=res.getString("department");
				int salary=res.getInt("salary");
				Employee e=new Employee(id,name,email,department,salary);
				return e;
			}
		}
		catch(Exception e1)
		{
			e1.printStackTrace();
		}
		return null;
	}
	
	
	public List<Employee> getAll()
	{
		try
		{
			statemnt=conncetion.prepareStatement(SELECT_QUERY1);
			ResultSet res=statemnt.executeQuery();
			ArrayList<Employee> list=new ArrayList<Employee> ();
			while(res.next())
			{
				int id=res.getInt("id");
				String name=res.getString("name");
				String email=res.getString("email");
				String department=res.getString("department");
				int salary=res.getInt("salary");
				Employee e=new Employee(id,name,email,department,salary);
				list.add(e);
			}
			return list;
		}
		catch(Exception e1)
		{
			e1.printStackTrace();
		}
		return null;
	}
}
